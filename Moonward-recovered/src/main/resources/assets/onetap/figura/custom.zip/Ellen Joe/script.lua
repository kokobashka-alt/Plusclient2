-- Auto generated script file --

--hide vanilla model
vanilla_model.PLAYER:setVisible(false)

vanilla_model.ARMOR:setVisible(false)

local squapi = require("SquAPI")



local myTail = {
    models.model.root.Body.Tail,
    models.model.root.Body.Tail.A,
    models.model.root.Body.Tail.A.B,
    models.model.root.Body.Tail.A.B.C,
    models.model.root.Body.Tail.A.B.C.D
}

squapi.tail:new(myTail,
nil,    --(15) idleXMovement
nil,    --(5) idleYMovement
nil,    --(1.2) idleXSpeed
nil,    --(2) idleYSpeed
nil,    --(2) bendStrength
nil,    --(0) velocityPush
nil,    --(0) initialMovementOffset
-1,    --(1) offsetBetweenSegments
.05,    --(.005) stiffness
nil,    --(.9) bounce
nil,    --(90) flyingOffset
nil,    --(-90) downLimit
nil     --(45) upLimit
)

squapi.smoothHead:new(
    models.model.root.Head
)

squapi.bewb:new(
    models.model.root.Body.Tits.BoobR, --element
    nil, --(2) bendability
    nil, --(0.05) stiff
    .6, --(0.9) bounce
    nil, --(true) doIdle
    1.3, --(4) idleStrength
    nil, --(1) idleSpeed
    nil, --(-10) downLimit
    10  --(25) upLimit
)

squapi.bewb:new(
    models.model.root.Body.Tits.BoobL, --element
    nil, --(2) bendability
    nil, --(0.05) stiff
    .6, --(0.9) bounce
    nil, --(true) doIdle
    1.3, --(4) idleStrength
    nil, --(1) idleSpeed
    nil, --(-10) downLimit
    10  --(25) upLimit
)

squapi.bewb:new(
    models.model.root.Body.Tits.Midsection, --element
    nil, --(2) bendability
    .08, --(0.05) stiff
    .6, --(0.9) bounce
    nil, --(true) doIdle
    1, --(4) idleStrength
    nil, --(1) idleSpeed
    nil, --(-10) downLimit
    0  --(25) upLimit
)

squapi.eye:new(
    models.model.root.Head.eyeR,
    .4,
    1.1,
    nil,
    nil
)
squapi.eye:new(
    models.model.root.Head.eyeL,
    nil,
    nil,
    nil,
    nil
)

squapi.eye:new(
    models.model.root.Head.eyelid,
    0,
    0,
    nil,
    nil
)

local skirtPhysics = require("skirt_physics")

skirtPhysics.new(models.model.root.Body.Skirt)