---レジストリの種類を示す列挙型
---@alias CompatibilityUtils.RegistryType
---| "BLOCK"    # ブロック
---| "ITEM"     # アイテム
---| "PARTICLE" # パーティクル
---| "SOUND"    # サウンド
---| "ENTITY"   # エンティティ

---@class (exact) CompatibilityUtils Minecraftのゲームバージョンが異なっていてもある程度互換性を確保するためのユーティリティクラス
---@field package TARGET_MC_VERSION string アバターが想定しているMinecraftの最低バージョン。このバージョンより古い場合は読み込み時に警告メッセージが表示される。
---@field package ALTERNATIVE_ENTRIES {block: Minecraft.blockID, item: Minecraft.itemID, particle: Minecraft.particleID, sound: Minecraft.soundID, entity: Minecraft.entityID} レジストリに存在しないIDが指定された場合に代わりに使用するIDを格納するテーブル
---@field package registries {block: Minecraft.blockID[], item: Minecraft.itemID[], particle: Minecraft.particleID[], sound: Minecraft.soundID[], entity: Minecraft.entityID[]} ゲームから取得した全アイテム名を保持するテーブル
---@field package checkedTable {block: {[Minecraft.blockID]: boolean}, item: {[Minecraft.itemID]: boolean}, particle: {[Minecraft.particleID]: boolean}, sound: {[Minecraft.soundID]: boolean}, entity: {[Minecraft.entityID]: boolean}} レジストリへの確認が済んでいるIDを保持するテーブル
local CompatibilityUtils = {

    TARGET_MC_VERSION = "1.21.4";

    ALTERNATIVE_ENTRIES = {
        block = "minecraft:dirt";
        item = "minecraft:barrier";
        particle = "minecraft:poof";
        sound = "minecraft:empty";
        entity = "minecraft:zombie"
    };

    registries = {};
    checkedTable = {
        block = {};
        item = {};
        particle = {};
        sound = {};
        entity = {};
    };

    ---初期化関数
    ---@param self CompatibilityUtils
    init = function (self)
        -- レジストリの取得
        self.registries.block = client.getRegistry("minecraft:block")
        self.registries.item = client.getRegistry("minecraft:item")
        self.registries.particle = client.getRegistry("minecraft:particle_type")
        self.registries.sound = client.getRegistry("minecraft:sound_event")
        self.registries.entity = client.getRegistry("minecraft:entity_type")

        for name, _ in pairs(self.registries) do
            table.sort(self.registries[name])
        end

        -- 代替値のフラグ立て
        for index, ct in pairs(self.checkedTable) do
            ct[self.ALTERNATIVE_ENTRIES[index]] = true
        end

        -- 非推奨ゲームバージョンに対する警告
        if host:isHost() and StringUtils.isNewerVersion(self.TARGET_MC_VERSION, client:getVersion()) then
            EventManager.events["ON_LOCALE_READY"]:register(function ()
                EventManager.events["ON_LOCALE_READY"]:remove("compatibility_utils_old_version_warning")
                print(Locale:getLocalizedText("message.compatibility_utils.old_version_warning"):format(self.TARGET_MC_VERSION))
            end, "compatibility_utils_old_version_warning")
        end

        self:injectToBlockTaskSetBlock()
        self:injectToItemTaskSetItem()
        self:injectToParticlesNewParticle()
        self:injectToSoundsPlaySound()
        self:injectToEntitySetNbt()
        self:injectToRendererSetPostEffect()
    end;

    ---指定されたターゲットがレジストリに登録されているかどうかを返す。
    ---@param self CompatibilityUtils
    ---@param registryType CompatibilityUtils.RegistryType 検索をかける対象のレジストリ
    ---@param target string 検索対象名。"minecraft:"を抜かないこと。
    ---@return boolean idFound 指定されたターゲットがレジストリで見つかったかどうか
    find = function (self, registryType, target)
        ---リスト内の中央の要素（偶数の場合は中央から1つ左の要素）と指定されたターゲットのUnicode順を比較する。
        ---@param from integer リストの検索開始のインデックス番号
        ---@param to integer リストの検索終了のインスタンス番号（指定したインデックス番号の要素も検索に含む）
        ---@return integer compareResult 比較結果。0は同じ文字列、1はターゲットの方が大きい、-1はターゲットの方が小さいことを表す。
        local function compareToCenterElement(from, to)
            local centerIndex = math.floor((to - from) / 2) + from
            if self.registries[StringUtils.lower(registryType)][centerIndex] < target then
                return 1
            elseif self.registries[StringUtils.lower(registryType)][centerIndex] > target then
                return -1
            else
                return 0
            end
        end

        local startIndex = 1
        local endIndex = #self.registries[StringUtils.lower(registryType)]
        while startIndex < endIndex do
            local compareResult = compareToCenterElement(startIndex, endIndex)
            if compareResult == 1 then
                startIndex = math.floor((endIndex - startIndex) / 2) + startIndex + 1
            elseif compareResult == -1 then
                endIndex = math.floor((endIndex - startIndex) / 2) + startIndex
            else
                break
            end
        end
        if startIndex == endIndex then
            return compareToCenterElement(startIndex, endIndex) == 0
        else
            return true
        end
    end;

    ---指定されたブロックIDがレジストリに登録されているか確認する。レジストリに未登録の場合は"minecraft:dirt"を返す。
    ---@param self CompatibilityUtils
    ---@param block Minecraft.blockID 確認対象のブロックID
    ---@return Minecraft.blockID blockId レジストリに登録してある場合は確認対象のブロックIDをそのまま返し、未登録の場合は"minecraft:dirt"を返す。
    checkBlock = function (self, block)
        if self.checkedTable.block[block] == nil then
            self.checkedTable.block[block] = self:find("BLOCK", block)
        end
        return self.checkedTable.block[block] and block or self.ALTERNATIVE_ENTRIES.block
    end;

    ---指定されたアイテムIDがレジストリに登録されているか確認する。レジストリに未登録の場合は"minecraft:barrier"を返す。
    ---@param self CompatibilityUtils
    ---@param item Minecraft.itemID 確認対象のアイテムID
    ---@return Minecraft.itemID itemId レジストリに登録してある場合は確認対象のアイテムIDをそのまま返し、未登録の場合は"minecraft:barrier"を返す。
    checkItem = function (self, item)
        if self.checkedTable.item[item] == nil then
            self.checkedTable.item[item] = self:find("ITEM", item)
        end
        return self.checkedTable.item[item] and item or self.ALTERNATIVE_ENTRIES.item
    end;

    ---指定されたパーティクルIDがレジストリに登録されているか確認する。レジストリに未登録の場合は"minecraft:poof"を返す。
    ---@param self CompatibilityUtils
    ---@param particle Minecraft.particleID 確認対象のパーティクルID
    ---@return Minecraft.particleID particleId レジストリに登録してある場合は確認対象のパーティクルIDをそのまま返し、未登録の場合は"minecraft:poof"を返す。
    checkParticle = function (self, particle)
        if self.checkedTable.particle[particle] == nil then
            self.checkedTable.particle[particle] = self:find("PARTICLE", particle)
        end
        return self.checkedTable.particle[particle] and particle or self.ALTERNATIVE_ENTRIES.particle
    end;

    ---指定されたサウンドIDがレジストリに登録されているか確認する。レジストリに未登録の場合は"minecraft:empty"を返す。
    ---@param self CompatibilityUtils
    ---@param sound Minecraft.soundID 確認対象のサウンドID
    ---@return Minecraft.soundID soundId レジストリに登録してある場合は確認対象のサウンドIDをそのまま返し、未登録の場合は"minecraft:empty"を返す。
    checkSound = function (self, sound)
        if self.checkedTable.sound[sound] == nil then
            self.checkedTable.sound[sound] = self:find("SOUND", sound)
        end
        return self.checkedTable.sound[sound] and sound or self.ALTERNATIVE_ENTRIES.sound
    end;

    ---指定されたエンティティIDがレジストリに登録されているか確認する。レジストリに未登録の場合は"minecraft:zombie"を返す。
    ---@param self CompatibilityUtils
    ---@param entity Minecraft.entityID 確認対象のエンティティID
    ---@return Minecraft.entityID entityId レジストリに登録してある場合は確認対象のエンティティIDをそのまま返し、未登録の場合は"minecraft:zombie"を返す。
    checkEntity = function (self, entity)
        if self.checkedTable.entity[entity] == nil then
            self.checkedTable.entity[entity] = self:find("ENTITY", entity)
        end
        return self.checkedTable.entity[entity] and entity or self.ALTERNATIVE_ENTRIES.entity
    end;

    ---`models:newBlock():setBlock()`メソッドに対し、ブロックIDのチェック機能を注入する。
    ---@param self CompatibilityUtils
    injectToBlockTaskSetBlock = function (self)
        local dummyBlock = models:newBlock("dummy_block")
        local blockMT = getmetatable(dummyBlock)
        local originalSetBlockFunc = blockMT.__index.setBlock

        ---@param self2 BlockTask
        ---@param block BlockState|Minecraft.blockID
        blockMT.__index.setBlock = function (self2, block)
            if type(block) == "BlockState" then
                return originalSetBlockFunc(self2, block)
            else
                local trueBlockId = block
                if trueBlockId:find(":") == nil then
                    trueBlockId = "minecraft:" .. block
                end
                local stateBracketStart, stateBracketEnd = trueBlockId:find("%b[]")
                local blockState = ""
                if stateBracketStart ~= nil and stateBracketEnd ~= nil then
                    blockState = trueBlockId:sub(stateBracketStart, stateBracketEnd)
                    trueBlockId = trueBlockId:sub(1, stateBracketStart - 1)
                end
                trueBlockId = self:checkBlock(trueBlockId)
                if trueBlockId == self.ALTERNATIVE_ENTRIES.block then
                    blockState = ""
                end
                return originalSetBlockFunc(self2, self:checkBlock(trueBlockId) .. blockState)
            end
        end

        models:removeTask("dummy_block")
    end;

    ---`models:newItem():setItem()`メソッドに対し、アイテムIDのチェック機能を注入する。
    ---@param self CompatibilityUtils
    injectToItemTaskSetItem = function (self)
        local dummyItem = models:newItem("dummy_item")
        local itemMT = getmetatable(dummyItem)
        local originalSetItemFunc = itemMT.__index.setItem

        ---@param self2 ItemTask
        ---@param item ItemStack|Minecraft.itemID
        itemMT.__index.setItem = function (self2, item)
            if type(item) == "ItemStack" then
                return originalSetItemFunc(self2, item)
            else
                local trueItemId = item
                if trueItemId:find(":") == nil then
                    trueItemId = "minecraft:" .. trueItemId
                end
                return originalSetItemFunc(self2, self:checkItem(trueItemId))
            end
        end

        models:removeTask("dummy_item")
    end;

    ---ParticleAPIを改変し、`particles:newParticle()`メソッドに対し、パーティクルIDのチェック機能を注入する。
    ---@param self CompatibilityUtils
    injectToParticlesNewParticle = function (self)
        local particlesMT = figuraMetatables.ParticleAPI
        local originalParticleIndexFunc = particlesMT.__index

        ---@param self2 ParticleAPI
        ---@param key any
        particlesMT.__index = function (self2, key)
            if key == "newParticle" then
                ---@param self3 ParticleAPI
                ---@param name Minecraft.particleID
                return function (self3, name, ...)
                    local trueParticleId = name
                    if trueParticleId:find(":") == nil then
                        trueParticleId = "minecraft:" .. trueParticleId
                    end
                    local arg = ""
                    local bracketMatch = trueParticleId:match("{(.-)}")
                    if bracketMatch ~= nil then
                        local bracketIndex = trueParticleId:find("{")
                        if StringUtils.isNewerOrEqualVersion(client:getVersion(), "1.21.9") then
                            arg = "{" .. bracketMatch .. "}"
                        end
                        trueParticleId = trueParticleId:sub(1, bracketIndex - 1)
                    end
                    local spaceIndex = trueParticleId:find(" ")
                    if spaceIndex ~= nil then
                        arg = trueParticleId:sub(spaceIndex + 1)
                        trueParticleId = trueParticleId:sub(1, spaceIndex - 1)
                    end
                    trueParticleId = self:checkParticle(trueParticleId)
                    if trueParticleId == self.ALTERNATIVE_ENTRIES.particle then
                        arg = ""
                    end
                    if trueParticleId == "minecraft:item" and StringUtils.isNewerOrEqualVersion(client:getVersion(), "1.20.5") then
                        return originalParticleIndexFunc(self2, "newParticle")(self3, "minecraft:item{item:{id:\"" .. arg .. "\"}}", ...)
                    else
                        return originalParticleIndexFunc(self2, "newParticle")(self3, trueParticleId .. (arg:sub(1, 1) == "{" and "" or " ") .. arg, ...)
                    end
                end
            else
                return originalParticleIndexFunc(self2, key)
            end
        end;
    end;

    ---SoundAPIを改変し、`sounds:playSound()`メソッドに対し、サウンドIDのチェック機能を注入する。
    ---@param self CompatibilityUtils
    injectToSoundsPlaySound = function (self)
        local soundsMT = figuraMetatables.SoundAPI
        local originalSoundIndexFunc = soundsMT.__index

        ---@param self2 SoundAPI
        ---@param key any
        soundsMT.__index = function (self2, key)
            if key == "playSound" then
                return function (self3, soundName, ...)
                    local trueSoundId = soundName
                    if trueSoundId:find(":") == nil then
                        trueSoundId = "minecraft:" .. trueSoundId
                    end
                    return originalSoundIndexFunc(self2, "playSound")(self3, self:checkSound(trueSoundId), ...)
                end
            else
                return originalSoundIndexFunc(self2, key)
            end
        end;
    end;

    ---`models:newEntity():setNbt()`メソッドに対し、エンティティIDのチェック機能を注入する。
    ---@param self CompatibilityUtils
    injectToEntitySetNbt = function (self)
        local dummyEntity = models:newEntity("dummy_entity")
        local entityMT = getmetatable(dummyEntity)
        local originalSetNbtFunc = entityMT.__index.setNbt

        ---@param self2 EntityTask
        ---@param entityId Minecraft.entityID
        ---@param nbt? string
        entityMT.__index.setNbt = function (self2, entityId, nbt)
            local trueEntityId = entityId
            local trueNbt = nbt
            if trueNbt == nil then
                trueEntityId = nil
                trueNbt = entityId
            end

            if trueEntityId ~= nil then
                if trueEntityId:find(":") == nil then
                    trueEntityId = "minecraft:" .. trueEntityId
                end

                local trueEntityIdPrev = trueEntityId
                trueEntityId = self:checkEntity(trueEntityId)

                return originalSetNbtFunc(self2, trueEntityId, trueEntityId == trueEntityIdPrev and trueNbt or "{}")
            else
                return originalSetNbtFunc(self2, trueNbt)
            end
        end

        models:removeTask("dummy_entity")
    end;

    ---RendererAPIを改変し、`renderer:setPostEffect()`メソッドに対し、ゲームバージョンチェック機能を注入する。
    injectToRendererSetPostEffect = function ()
        local rendererMT = figuraMetatables.RendererAPI
        local originalRendererIndexFunc = rendererMT.__index

        ---@param self2 RendererAPI
        ---@param key any
        rendererMT.__index = function (self2, key)
            if key == "setPostEffect" then
                return function (self3, effect)
                    -- ゲームバージョン1.20.5以降、ゲーム内レンダープロファイルが削除され、以降アクセスを試みるとエラーになる。
                    if StringUtils.isNewerOrEqualVersion("1.20.5", client:getVersion()) then
                        return originalRendererIndexFunc(self2, "setPostEffect")(self3, effect)
                    else
                        return originalRendererIndexFunc(self2, "setPostEffect")
                    end
                end
            else
                return originalRendererIndexFunc(self2, key)
            end
        end;
    end;
}

return CompatibilityUtils
