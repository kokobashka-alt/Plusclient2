---@class (exact) Character01b.ExSkillSplashParticleManager : SpawnObjectManager Exスキルでで使用するスプラッシュパーティクルを管理するクラス
---@field public objects Character01b.ExSkillSplashParticle[] インスタンスで制御するオブジェクトのテーブル
local ExSkillSplashParticleManager = {
    ---コンストラクタ
    ---@return Character01b.ExSkillSplashParticleManager
    new = function (parent)
        ---@type Character01b.ExSkillSplashParticleManager
        local instance = MiscUtils.instantiate(Character01b_ExSkillSplashParticleManager, SpawnObjectManager, parent)

        instance.managerName = "ex_skill_1_splash_particle"

        return instance
    end;

    ---初期化関数
    init = function ()
        ---@diagnostic disable-next-line: discard-returns
        models.models.ex_skill_1.Gui:newPart("script_ex_skill_1_splash_particles")
    end;

    ---Exスキルのスプラッシュパーティクルのインスタンスを生成して返す。
    ---@param pos Vector2 パーティクルをスポーンさせる画面上の座標
    ---@param velocity Vector2 パーティクルの速度
    ---@return Character01b.ExSkillSplashParticle instance 生成したインスタンス
    getObject = function (_, pos, velocity)
        return Character01b_ExSkillSplashParticle.new(pos, velocity)
    end;

    ---Exスキルのスプラッシュパーティクルをスポーンさせる。
    ---@param self Character01b.ExSkillSplashParticleManager
    ---@param pos Vector2 パーティクルをスポーンさせる画面上の座標
    ---@param velocity Vector2 パーティクルの速度
    spawn = function (self, pos, velocity)
        SpawnObjectManager.spawn(self, pos, velocity)
    end;
}

return ExSkillSplashParticleManager
